//Wyatt Wilson
// Final Project

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JButton;
import javax.swing.JOptionPane;
import java.awt.BorderLayout;
import java.awt.GridLayout;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;


public class MainMenuGUI {

    private JFrame frame;
    private AppController controller;

    public MainMenuGUI() {
        // controllorer 
        this.controller = new AppController();
        this.initializeUI();
    }

    private void initializeUI() {
        // Set up the Java Window frame setup
        frame = new JFrame("Interactive Application Dashboard");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setSize(500, 350);
        frame.setLocationRelativeTo(null);

        JPanel panel = new JPanel();
        panel.setLayout(new GridLayout(4, 1, 10, 10));

        // Create interactive application
        JButton btnViewArray = new JButton("Display Live Status Array");
        JButton btnExportJson = new JButton("Convert & Process JSON Export");
        JButton btnModifyEnum = new JButton("Modify Menu Setting Runtime Variable");
        JButton btnExit = new JButton("Exit Application System");

        // raw display
        btnViewArray.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                controller.populateDisplayArray();
                String[] currentArray = controller.getDisplayArray();
                
                StringBuilder displayMsg = new StringBuilder("Current Loaded Configuration Array Matrix:\n");
                for (String item : currentArray) {
                    displayMsg.append("- ").append(item).append("\n");
                }
                JOptionPane.showMessageDialog(frame, displayMsg.toString(), "Array Display Info", JOptionPane.INFORMATION_MESSAGE);
            }
        });

        // makes mock JSon
        btnExportJson.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String generatedJson = controller.convertArrayToJson();
                // Prints data array out safely 
                System.out.println("DEBUG GENERATED STRING OUT:\n" + generatedJson);
                // Processes parsed checks on string inputs
                controller.processJsonExport(generatedJson);
            }
        });

        //adjusts enmum in runtime
        btnModifyEnum.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String newTime = JOptionPane.showInputDialog(frame, "Enter a new custom value for Time Display metric:", "Update Settings Matrix", JOptionPane.PLAIN_MESSAGE);
                if (newTime != null && !newTime.trim().isEmpty()) {
                    MenuSetting.TIME_DISPLAY.setDisplayValue("Current Time: " + newTime);
                    JOptionPane.showMessageDialog(frame, "Runtime properties successfully modified!");
                }
            }
        });

        //termination trigger
        btnExit.addActionListener(e -> System.exit(0));

        // Group component bindings onto parent views
        panel.add(btnViewArray);
        panel.add(btnExportJson);
        panel.add(btnModifyEnum);
        panel.add(btnExit);

        frame.add(panel, BorderLayout.CENTER);
    }

    public void display() {
        // Enforce application security loop validation
        boolean passGate = controller.authenticateUser();
        if (passGate) {
            frame.setVisible(true);
        } else {
            JOptionPane.showMessageDialog(null, "Security Authorization Failed. Terminating Thread Execution.", "Access Denied", JOptionPane.ERROR_MESSAGE);
            System.exit(0);
        }
    }

    //execution block
    public static void main(String[] args) {
        // Run application menu initialization sequences
        MainMenuGUI appWindow = new MainMenuGUI();
        appWindow.display();
    }
}