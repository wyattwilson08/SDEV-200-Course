//Wyatt Wilson
// Final



public enum MenuSetting {
    TIME_DISPLAY("Current Time: 12:00 PM"),
    THEME_DISPLAY("Default Dark Theme"),
    VERSION_DISPLAY("v1.0.0-Beta");

    private String displayValue;

    // Ch4: Constructor inside an enum
    private MenuSetting(String displayValue) {
        this.displayValue = displayValue; // Chapter 4: Use of the 'this' reference
    }

    public String getDisplayValue() { // Chapter 3: Getter
        return this.displayValue;
    }

    public void setDisplayValue(String displayValue) { // Chapter 3: Setter
        this.displayValue = displayValue;
    }
}