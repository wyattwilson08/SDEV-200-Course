//Wyatt Wilson
// Final Project

import javax.swing.JOptionPane;

public class AppController extends BaseConfig { // Inheritance structure

    // static field for security
    private static final String MASTER_PASSWORD = "Admin";

    // nested inner class
    public static class SecurityException extends Exception {
        public SecurityException(String message) {
            super(message);
        }
    }

    public AppController() {
        super(); // Invokes parent constructor
    }
    // while loop security check 
    public boolean authenticateUser() {
        int attempts = 0;
        boolean isAuthenticated = false;

        // Loop runs until access granted or user cancels/fails 3 times
        while (!isAuthenticated && attempts < 3) {
            // IO boxes
            String input = JOptionPane.showInputDialog(null, "Enter Application Password:", "Security Gate", JOptionPane.QUESTION_MESSAGE);
            
            if (input == null) {
                break; // User canceled the dialog box
            }

            
            if (input.equals(MASTER_PASSWORD)) {
                isAuthenticated = true;
                JOptionPane.showMessageDialog(null, "Access Granted!");
            } else {
                attempts++;
                // Chapter 2: Println concatenation
                System.out.println("Failed password attempt count: " + attempts);
                JOptionPane.showMessageDialog(null, "Incorrect Password. Try again.", "Auth Error", JOptionPane.ERROR_MESSAGE);
            }
        }
        return isAuthenticated;
    }

    // Chapter 6-7 loop and string methods and verfication
    public void processJsonExport(String rawJsonInput) {
        // Chapter 7: Correct use of the length method
        if (rawJsonInput != null && rawJsonInput.length() > 0) {
            
            // 1 nest for elif loop
            if (rawJsonInput.startsWith("{") && rawJsonInput.endsWith("}")) {
                
                //parsing json data to value
                try {
                    String extractedNum = "101"; // Hardcoded mockup substring match
                    int parsedValue = Integer.parseInt(extractedNum); // Chapter 7: Converting string to number
                    
                    // Chapter 2: Variable declaration of major types (double, Boolean)
                    double executionTimeMs = 14.52;
                    Boolean exportSuccess = true;

                    //arthetmetic to stimulate time
                    executionTimeMs += 2.5; 

                    JOptionPane.showMessageDialog(null, "JSON Data valid!\nParsed Token: " + parsedValue + "\nSuccess Status: " + exportSuccess);
                } catch (NumberFormatException e) {
                    JOptionPane.showMessageDialog(null, "Failed to parse numeric value from payload.", "Error", JOptionPane.ERROR_MESSAGE);
                }
            } else {
                JOptionPane.showMessageDialog(null, "Invalid JSON enclosing characters.", "Format Error", JOptionPane.WARNING_MESSAGE);
            }
        }
    }

    // Maps Enum attributes
    public void populateDisplayArray() {
        //forloop
        MenuSetting[] settings = MenuSetting.values();
        for (int i = 0; i < settings.length; i++) {
            if (i < this.displayArray.length) {
                this.displayArray[i] = settings[i].name() + " -> " + settings[i].getDisplayValue();
            }
        }
    }

    // String to Jason
    public String convertArrayToJson() {
        this.populateDisplayArray();
        StringBuilder jsonBuilder = new StringBuilder();
        jsonBuilder.append("{\n  \"menuItems\": [\n");
        
        for (int i = 0; i < this.displayArray.length; i++) {
            jsonBuilder.append("    \"").append(this.displayArray[i]).append("\"");
            if (i < this.displayArray.length - 1) {
                jsonBuilder.append(",\n");
            }
        }
        jsonBuilder.append("\n  ]\n}");
        return jsonBuilder.toString();
    }
}
