//Wyatt Wilson
// Final Project

import java.io.File;

public class BaseConfig {
    // Static Feild and consant for key 
    public static final String DEFAULT_CRYPTO_KEY = "ADMIN"; 
    
    // Inheritance field
    protected String[] displayArray; 
    protected File securityFilePath; 

    // Constructor
    public BaseConfig() {
        // Chapter 2: Initialization & Chapter 7: Array instantiation
        this.displayArray = new String[3]; 
        this.securityFilePath = new File("security_config.txt");
    }

    // Overloaded constructor
    public BaseConfig(String customPath) {
        this.displayArray = new String[3];
        this.securityFilePath = new File(customPath);
    }

    // Instance methods
    public String[] getDisplayArray() {
        return this.displayArray;
    }
}